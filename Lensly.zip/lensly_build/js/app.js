// ── Splash stars ──
(function(){
  const w=document.getElementById('splashStars');if(!w)return;
  for(let i=0;i<60;i++){
    const s=document.createElement('div');s.className='star-p';
    const sz=Math.random()*2.5+.8;
    s.style.cssText=`width:${sz}px;height:${sz}px;left:${Math.random()*100}%;top:${Math.random()*100}%;animation-duration:${1.5+Math.random()*3}s;animation-delay:${Math.random()*4}s;`;
    w.appendChild(s);
  }
})();
const IMAGES = {
  soflens59: "assets/images/soflens59.png",
  soflens_astig: "assets/images/soflens_astig.png",
  purevision2: "assets/images/purevision2.png",
  purevision2_astig: "assets/images/purevision2_astig.png",
  aspire_pro: "assets/images/aspire_pro.png",
  aspire_air: "assets/images/aspire_air.png",
  biomedics_now: "assets/images/biomedics_now.png",
  proclear: "assets/images/proclear.png"
};


// ═══════════════════════════════════════
//  PRODUCTS — with category tags for proper segregation
// ═══════════════════════════════════════
const PRODUCTS=[
  {id:1,img:'soflens59',brand:'Bausch + Lomb',name:'SofLens® 59',material:'hilafilcon B',
   type:'Regular Soft Contact Lens',wearDays:30,
   desc:'SofLens 59 provides excellent all-day comfort and crisp vision. Made with hilafilcon B for healthy oxygen flow. Suitable for myopia and hyperopia. 6 lenses per box.',
   badges:['6 Lenses/Box','All Powers','Monthly Wear'],price:850,oldPrice:1100,rating:4.2,reviews:312,
   forAstig:false,isNew:false,
   // category tags: which collections this product genuinely fits
   tags:['everyday','work','pretty'],
   powers:['-0.50','-0.75','-1.00','-1.25','-1.50','-1.75','-2.00','-2.25','-2.50','-2.75','-3.00','-3.25','-3.50','-3.75','-4.00','-4.50','-5.00','-5.50','-6.00','+0.50','+0.75','+1.00','+1.25','+1.50','+1.75','+2.00','+2.50','+3.00','+3.50','+4.00']},
  {id:2,img:'soflens_astig',brand:'Bausch + Lomb',name:'SofLens® Toric',material:'alphafilcon A',
   type:'Toric – For Astigmatism',wearDays:30,
   desc:'Designed for astigmatism. Stable, clear vision with unique toric design that corrects cylindrical power throughout the day — ideal for long work or study sessions.',
   badges:['For Astigmatism','6 Lenses/Box','Toric Design'],price:1200,oldPrice:1500,rating:4.3,reviews:189,
   forAstig:true,isNew:false,
   tags:['work','dreamers'],
   powers:['-0.75','-1.25','-1.75','-2.25','-2.75','-3.25','-3.75','-4.25','-4.75']},
  {id:3,img:'purevision2',brand:'Bausch + Lomb',name:'PureVision® 2',material:'balafilcon A',
   type:'Extended Wear – HD Vision',wearDays:30,
   desc:'HD optics with high oxygen permeability. Reduces halos and glare for superior night vision — built for screen-heavy days and fast reflexes. Extended wear comfort.',
   badges:['HD Vision','6 Lenses/Box','Extended Wear','Night Vision'],price:1350,oldPrice:1800,rating:4.5,reviews:427,
   forAstig:false,isNew:false,
   tags:['gamer','work','dreamers'],
   powers:['-0.50','-0.75','-1.00','-1.25','-1.50','-1.75','-2.00','-2.25','-2.50','-2.75','-3.00','-3.25','-3.50','-3.75','-4.00','-4.50','-5.00','-5.50','-6.00','-6.50','-7.00','-8.00','-9.00','-10.00','-11.00','-12.00','+0.50','+1.00','+1.50','+2.00','+2.50','+3.00','+4.00','+5.00','+6.00']},
  {id:4,img:'purevision2_astig',brand:'Bausch + Lomb',name:'PureVision® 2 Toric',material:'balafilcon A',
   type:'HD Toric – For Astigmatism',wearDays:30,
   desc:'Most advanced toric lens with HD optics. AutoAlignDesign™ keeps lenses perfectly positioned for consistently clear vision — gamers and night-shift workers love the reduced glare.',
   badges:['NEW','For Astigmatism','HD Optics','6 Lenses/Box'],price:1650,oldPrice:2200,rating:4.6,reviews:203,
   forAstig:true,isNew:true,
   tags:['gamer','work'],
   powers:['-0.75','-1.25','-1.75','-2.25','-2.75','-3.25','-3.75','-4.25','-4.75','-5.25','-5.75']},
  {id:5,img:'aspire_pro',brand:'CooperVision',name:'Aspire™ Pro',material:'3rd Gen Silicone-Hydrogel',
   type:'Monthly Soft Lens',wearDays:30,
   desc:'Aspire Pro uses 3rd gen silicone-hydrogel for maximum oxygen permeability. Lightweight and breathable — perfect for long flights, road trips, and busy travel days.',
   badges:['3 Lenses/Box','Monthly','All Day Comfort'],price:720,oldPrice:950,rating:4.4,reviews:258,
   forAstig:false,isNew:false,
   tags:['travel','everyday','pretty'],
   powers:['-0.50','-0.75','-1.00','-1.25','-1.50','-1.75','-2.00','-2.25','-2.50','-2.75','-3.00','-3.50','-4.00','-4.50','-5.00','-5.50','-6.00','+0.50','+1.00','+1.50','+2.00','+2.50','+3.00']},
  {id:6,img:'aspire_air',brand:'CooperVision',name:'Aspire™ Air',material:'3rd Gen Silicone-Hydrogel',
   type:'Monthly UV-Blocking Lens',wearDays:30,
   desc:'Aspire Air combines 3rd gen silicone-hydrogel with UV blocking — your eyes stay protected on beach days, hikes, and outdoor adventures while travelling.',
   badges:['3 Lenses/Box','UV Blocking','Monthly'],price:680,oldPrice:900,rating:4.3,reviews:196,
   forAstig:false,isNew:false,
   tags:['travel','dreamers'],
   powers:['-0.50','-0.75','-1.00','-1.25','-1.50','-1.75','-2.00','-2.25','-2.50','-2.75','-3.00','-3.50','-4.00','-4.50','-5.00','-5.50','-6.00','+0.50','+1.00','+1.50','+2.00','+2.50','+3.00']},
  {id:7,img:'biomedics_now',brand:'CooperVision',name:'Biomedics® Now',material:'UV-Blocking Hydrogel',
   type:'Daily UV-Blocking Lens',wearDays:1,
   desc:'Outstanding UV blocking with 6 contact lenses per box. Fresh pair every day — simple, convenient and ideal for travel and on-the-go lifestyles.',
   badges:['6 Lenses/Box','UV Blocking','Daily Fresh'],price:560,oldPrice:750,rating:4.1,reviews:341,
   forAstig:false,isNew:false,
   tags:['travel','pretty','everyday'],
   powers:['-0.50','-0.75','-1.00','-1.25','-1.50','-1.75','-2.00','-2.25','-2.50','-2.75','-3.00','-3.25','-3.50','-3.75','-4.00','-4.50','-5.00','-5.50','-6.00','+0.50','+1.00','+1.50','+2.00','+2.50','+3.00']},
  {id:8,img:'proclear',brand:'CooperVision',name:'Proclear®',material:'PC Technology™',
   type:'Monthly Comfort Lens',wearDays:30,
   desc:'PC Technology™ attracts and retains water all day. Clinically proven for improved comfort — ideal for people chasing long study sessions, big dreams, and dry-eye-prone screen time.',
   badges:['6 Lenses/Box','PC Technology','Dry Eye Comfort'],price:890,oldPrice:1150,rating:4.5,reviews:412,
   forAstig:false,isNew:false,
   tags:['dreamers','pretty','work'],
   powers:['-0.50','-0.75','-1.00','-1.25','-1.50','-1.75','-2.00','-2.25','-2.50','-2.75','-3.00','-3.25','-3.50','-3.75','-4.00','-4.50','-5.00','-5.50','-6.00','-6.50','-7.00','-8.00','+0.50','+1.00','+1.50','+2.00','+2.50','+3.00','+4.00','+5.00','+6.00']}
];

// ═══════════════════════════════════════
//  COLLECTIONS — each maps to a real tag, so products are correctly segregated
// ═══════════════════════════════════════
const COLLECTIONS=[
  {key:'pretty',icon:'🌷',name:'Pretty Eyes Club',slogan:'Pretty eyes deserve premium care.',bg:'#FFE8F0',iconBg:'#FFE8F0'},
  {key:'dreamers',icon:'⭐',name:'Dreamers Collection',slogan:'For the eyes chasing big dreams.',bg:'#FFF8E1',iconBg:'#FFF8E1'},
  {key:'work',icon:'💻',name:'Work Warrior Collection',slogan:'Your eyes work overtime. Give them a raise.',bg:'#E3F2FD',iconBg:'#E3F2FD'},
  {key:'gamer',icon:'🎮',name:'Gamer Collection',slogan:'Lag in game? Fine. Lag in vision? Never.',bg:'#E8F5E9',iconBg:'#E8F5E9'},
  {key:'travel',icon:'✈️',name:'Travel Collection',slogan:'Serving looks and eye comfort.',bg:'#F3E5F5',iconBg:'#F3E5F5'},
  {key:'all',icon:'🛍️',name:'All Products',slogan:'Browse our full collection',bg:'#FFF3E0',iconBg:'#FFF3E0',isAll:true}
];

// ═══════════════════════════════════════
//  SLOGANS
// ═══════════════════════════════════════
const SLOGANS={
  home:["Life's blurry enough. Your vision doesn't have to be.","Staring at screens. Not settling for strain.","Focus on your goals. We'll handle the focus."],
  emptyCart:["Your future is loading... your cart should too.","Nothing here yet. Your eyes are waiting."],
  checkout:["Your eyes just filed a thank-you note.","Future you can already see the difference."],
  orderConfirm:["Your order is officially in sight. 👀 Thank you for ordering!","Your vision upgrade is on the way. Thank you for ordering!"],
  reorder:["Your lenses called. They deserve retirement.","Your eyes noticed. We noticed too. Time for a fresh pair?"]
};
function pickSlogan(arr){
  const k='lsi_'+arr[0].substring(0,8);
  let i=(parseInt(sessionStorage.getItem(k)||'-1')+1)%arr.length;
  sessionStorage.setItem(k,String(i));return arr[i];
}

// ═══════════════════════════════════════
//  SECURITY
// ═══════════════════════════════════════
const _e=s=>String(s).replace(/[<>"'`&]/g,c=>({'<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;','`':'&#96;','&':'&amp;'}[c]));
function safeStore(k,v){try{localStorage.setItem('lensly_'+k,JSON.stringify(v));}catch(e){}}
function safeRead(k,d){try{const v=localStorage.getItem('lensly_'+k);return v!=null?JSON.parse(v):d;}catch(e){return d;}}

// ═══════════════════════════════════════
//  SPLASH
// ═══════════════════════════════════════
const SPLASH_MS=7000;
function runSplash(){
  const bar=document.getElementById('splashBarFill');
  const start=Date.now();
  const biv=setInterval(()=>{const p=Math.min(100,((Date.now()-start)/SPLASH_MS)*100);if(bar)bar.style.width=p+'%';if(p>=100)clearInterval(biv);},60);
  const show=i=>{
    document.querySelectorAll('.sp-sl').forEach(s=>s.classList.remove('in','out'));
    document.querySelectorAll('.sp-dot').forEach(d=>d.classList.remove('on'));
    const el=document.getElementById('spl'+i),dt=document.getElementById('dot'+i);
    if(el)el.classList.add('in');if(dt)dt.classList.add('on');
  };
  const sk='splash_si';
  let si=(parseInt(sessionStorage.getItem(sk)||'-1')+1)%3;
  sessionStorage.setItem(sk,String(si));
  show(si);
  setTimeout(()=>{const e=document.getElementById('spl'+si);if(e)e.classList.add('out');si=(si+1)%3;setTimeout(()=>show(si),420);},2200);
  setTimeout(()=>{const e=document.getElementById('spl'+si);if(e)e.classList.add('out');si=(si+1)%3;setTimeout(()=>show(si),420);},4600);
  setTimeout(()=>goToPage('loginPage'),SPLASH_MS);
}

// ═══════════════════════════════════════
//  OTP — channel select + countdown
// ═══════════════════════════════════════
let _otp='',_otpTimer=null,_otpChannel='whatsapp';
function selectChannel(ch){
  _otpChannel=ch;
  document.getElementById('chWhatsapp').classList.toggle('on',ch==='whatsapp');
  document.getElementById('chSms').classList.toggle('on',ch==='sms');
}
function generateOtp(){
  // PRODUCTION: call WhatsApp Business API (free tier via Meta Cloud API) or
  // an SMS gateway with a free quota (e.g. Firebase Phone Auth) from your backend.
  // Client-side code must never hold real API keys — see backend spec.
  _otp=String(Math.floor(100000+Math.random()*900000));
  return _otp;
}
function startOtpTimer(){
  clearInterval(_otpTimer);
  let secs=60;
  const el=document.getElementById('otpTimer');
  if(el)el.innerHTML='OTP expires in <span>'+secs+'s</span>';
  _otpTimer=setInterval(()=>{
    secs--;
    if(el)el.innerHTML=secs>0?'OTP expires in <span>'+secs+'s</span>':'<span style="color:#E53E3E">OTP expired. Please resend.</span>';
    if(secs<=0){clearInterval(_otpTimer);_otp='';}
  },1000);
}

// ═══════════════════════════════════════
//  STATE
// ═══════════════════════════════════════
let isLoggedIn=false;
let cart=safeRead('cart',[])||[];
let currentProduct=null,selectedPower=null,selPayment=null;
let pageHistory=[],filteredProds=[...PRODUCTS];
let orderNum=1000+Math.floor(Math.random()*900);
let userProfile=safeRead('profile',{name:'',email:'',phone:''});
let pendingTryOnProduct=null;

// ═══════════════════════════════════════
//  NAVIGATION
// ═══════════════════════════════════════
function goToPage(id){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  const pg=document.getElementById(id);if(pg)pg.classList.add('active');
  window.scrollTo(0,0);
}
function goTo(id){
  if(!isLoggedIn&&id!=='loginPage'){showToast('Please login first');return;}
  const cur=document.querySelector('.page.active');if(cur)pageHistory.push(cur.id);
  goToPage(id);
  if(id==='cartPage')renderCart();
  if(id==='homePage'){renderCollections();renderRec('recScroll',0);}
  if(id==='checkoutPage')renderCheckoutSlogan();
  if(id==='profilePage')renderProfile();
  updateBadges();
}
function goBack(){
  if(pageHistory.length>0){
    const p=pageHistory.pop();goToPage(p);
    if(p==='cartPage')renderCart();
    if(p==='homePage'){renderCollections();renderRec('recScroll',0);}
    updateBadges();
  }else goHome();
}
function goHome(){
  if(!isLoggedIn)return;pageHistory=[];goToPage('homePage');
  renderCollections();renderRec('recScroll',0);updateBadges();
}

// ═══════════════════════════════════════
//  LOGIN
// ═══════════════════════════════════════
function googleLogin(){
  isLoggedIn=true;document.getElementById('userAvatar').textContent='G';
  showToast('✅ Logged in with Google!');checkReorderNotifications();goTo('homePage');
}
function openOtpModal(){document.getElementById('otpModal').classList.add('show');}
function closeOtpModal(){
  document.getElementById('otpModal').classList.remove('show');
  document.getElementById('step1').style.display='block';
  document.getElementById('step2').style.display='none';
  document.getElementById('phoneInput').value='';
  document.getElementById('otpInput').value='';
  clearInterval(_otpTimer);_otp='';
}
function sendOtp(){
  const ph=document.getElementById('phoneInput').value.trim();
  if(!ph||ph.replace(/\D/g,'').length<10){showToast('Enter a valid 10-digit number');return;}
  const otp=generateOtp();
  document.getElementById('phoneShow').textContent=ph;
  document.getElementById('channelShow').textContent=_otpChannel==='whatsapp'?'WhatsApp':'SMS';
  document.getElementById('step1').style.display='none';
  document.getElementById('step2').style.display='block';
  const hint=document.getElementById('otpHint');
  hint.textContent='Demo mode — OTP: '+otp+' (live SMS/WhatsApp requires backend, see setup notes)';
  hint.style.display='block';
  startOtpTimer();
  showToast((_otpChannel==='whatsapp'?'💬 WhatsApp':'✉️ SMS')+' OTP sent (demo mode)');
}
function verifyOtp(){
  if(!_otp){showToast('OTP expired. Please resend.');return;}
  const e=document.getElementById('otpInput').value.trim();
  if(!e||e.length!==6){showToast('Enter a 6-digit OTP');return;}
  if(e!==_otp){showToast('❌ Incorrect OTP. Try again.');return;}
  clearInterval(_otpTimer);
  closeOtpModal();isLoggedIn=true;
  document.getElementById('userAvatar').textContent='U';
  showToast('✅ Login successful!');checkReorderNotifications();goTo('homePage');
}

// ═══════════════════════════════════════
//  SEARCH
// ═══════════════════════════════════════
function openSearch(){document.getElementById('searchOverlay').classList.add('show');document.getElementById('searchInput').focus();}
function closeSearch(){document.getElementById('searchOverlay').classList.remove('show');document.getElementById('searchInput').value='';}
function handleSearch(q){
  const t=q.toLowerCase().trim();
  if(!t)return;
  const res=PRODUCTS.filter(p=>p.name.toLowerCase().includes(t)||p.brand.toLowerCase().includes(t)||p.type.toLowerCase().includes(t));
  openProdOverlayWithList(res,'Search results');
}
function handleOverlaySearch(q){
  const t=q.toLowerCase().trim();
  const base=window._overlayBaseList||PRODUCTS;
  if(!t){renderOverlayGrid(base);return;}
  renderOverlayGrid(base.filter(p=>p.name.toLowerCase().includes(t)||p.brand.toLowerCase().includes(t)||p.type.toLowerCase().includes(t)));
}

// ═══════════════════════════════════════
//  FILTER
// ═══════════════════════════════════════
function openFilter(){document.getElementById('filterDrawer').classList.add('open');document.getElementById('filterOverlay').classList.add('show');}
function closeFilter(){document.getElementById('filterDrawer').classList.remove('open');document.getElementById('filterOverlay').classList.remove('show');}
function toggleChip(el){el.classList.toggle('active');}
function toggleColorChip(el){el.classList.toggle('active');}
function clearBrandFilter(){
  document.querySelectorAll('#brandChips .chip').forEach(c=>c.classList.remove('active'));
  showToast('Brand filter cleared');
}
function applyFilter(){
  const brandsOn=[...document.querySelectorAll('#brandChips .chip.active')].map(c=>c.textContent.trim());
  const typeOn=[...document.querySelectorAll('#typeChips .chip.active')].map(c=>c.textContent.trim());
  const min=parseInt(document.getElementById('priceMin').value)||0;
  const max=parseInt(document.getElementById('priceMax').value)||99999;
  filteredProds=PRODUCTS.filter(p=>{
    const brandOk=!brandsOn.length||brandsOn.includes(p.brand);
    const typeOk=!typeOn.length||typeOn.some(t=>(t==='For Astigmatism'&&p.forAstig)||(t==='Regular'&&!p.forAstig)||(t==='HD Vision'&&p.type.includes('HD'))||(t==='Monthly'&&p.wearDays===30)||(t==='UV Blocking'&&p.type.toLowerCase().includes('uv')));
    return brandOk&&typeOk&&p.price>=min&&p.price<=max;
  });
  closeFilter();showToast('✅ Filters applied');
  if(document.getElementById('prodOverlay').classList.contains('open')){
    window._overlayBaseList=filteredProds;renderOverlayGrid(filteredProds);
  }
}
function clearFilter(){
  document.querySelectorAll('.chip').forEach(c=>c.classList.add('active'));
  document.querySelectorAll('#typeChips .chip').forEach(c=>c.classList.remove('active'));
  document.querySelectorAll('.cc-wrap').forEach(c=>c.classList.remove('active'));
  document.querySelector('.cc-wrap').classList.add('active'); // keep Clear colour default on
  document.getElementById('priceMin').value=300;
  document.getElementById('priceMax').value=3000;
  filteredProds=[...PRODUCTS];closeFilter();showToast('Filters cleared');
  if(document.getElementById('prodOverlay').classList.contains('open')){
    window._overlayBaseList=filteredProds;renderOverlayGrid(filteredProds);
  }
}

// ═══════════════════════════════════════
//  STARS
// ═══════════════════════════════════════
const stars=r=>[1,2,3,4,5].map(i=>`<span class="star" style="color:${i<=Math.round(r)?'#FFC107':'#E2E8F0'}">★</span>`).join('');

// ═══════════════════════════════════════
//  COLLECTIONS (vertical stack, properly mapped)
// ═══════════════════════════════════════
function renderCollections(){
  const el=document.getElementById('collectionsStack');if(!el)return;
  el.innerHTML=COLLECTIONS.map(c=>{
    const count=c.isAll?PRODUCTS.length:PRODUCTS.filter(p=>p.tags.includes(c.key)).length;
    return `<div class="col-row" onclick="openCollection('${c.key}')">
      <div class="col-icon-circle" style="background:${c.iconBg};">${c.icon}</div>
      <div class="col-row-text">
        <div class="col-row-name">${_e(c.name)}</div>
        <div class="col-row-slogan">${_e(c.slogan)}</div>
        <div class="col-row-count">${count} lens${count!==1?'es':''} available</div>
      </div>
      <div class="col-row-arrow">›</div>
    </div>`;
  }).join('');
}

function openCollection(key){
  if(!isLoggedIn){showToast('Please login first');return;}
  const coll=COLLECTIONS.find(c=>c.key===key);
  const list=key==='all'?PRODUCTS:PRODUCTS.filter(p=>p.tags.includes(key));
  openProdOverlayWithList(list,coll?coll.name:'Products');
}
function openProdOverlayWithList(list,title){
  window._overlayBaseList=list;
  document.getElementById('poTitle').textContent=title;
  renderOverlayGrid(list);
  document.getElementById('prodOverlay').classList.add('open');
  document.getElementById('prodOverlay').scrollTop=0;
}
function closeProdOverlay(){document.getElementById('prodOverlay').classList.remove('open');}

// ═══════════════════════════════════════
//  RENDER PRODUCT GRID
// ═══════════════════════════════════════
function renderOverlayGrid(list){
  const g=document.getElementById('prodOverlayGrid');
  if(!list||!list.length){
    g.innerHTML='<div class="empty-state" style="grid-column:1/-1;"><div class="empty-icon">🔍</div><p>No products found.<br>Try adjusting your filters.</p></div>';return;
  }
  g.innerHTML=list.map(p=>`
    <div class="product-card" onclick="openProduct(${p.id})">
      <div class="product-img-wrap">
        ${p.isNew?'<div class="prod-new-tag">NEW</div>':''}
        <div class="prod-brand-tag">${_e(p.brand)}</div>
        <img src="${IMAGES[p.img]}" alt="${_e(p.name)}" loading="lazy">
      </div>
      <div class="product-info">
        <div class="product-brand">${_e(p.brand)}</div>
        <div class="product-name">${_e(p.name)}</div>
        <div class="product-meta">${_e(p.type)} • ${_e(p.material)}</div>
        <div class="product-price">₹${p.price} <span class="per">/ box &nbsp;<s style="color:#ccc;font-size:.74rem;">₹${p.oldPrice}</s></span></div>
        <div class="stars">${stars(p.rating)}<span class="star-count">${p.rating} (${p.reviews})</span></div>
        <button class="add-cart-btn" onclick="event.stopPropagation();quickAdd(${p.id})">+ Add to Cart</button>
      </div>
    </div>`).join('');
}

// ═══════════════════════════════════════
//  REC
// ═══════════════════════════════════════
function renderRec(id,excl){
  const el=document.getElementById(id);if(!el)return;
  el.innerHTML=PRODUCTS.filter(p=>p.id!==excl).slice(0,6).map(p=>`
    <div class="rec-card" onclick="openProduct(${p.id})">
      <div class="rec-img"><img src="${IMAGES[p.img]}" alt="${_e(p.name)}" loading="lazy"></div>
      <div class="rec-name">${_e(p.name)}</div>
      <div class="rec-price">₹${p.price}</div>
    </div>`).join('');
}

// ═══════════════════════════════════════
//  CART
// ═══════════════════════════════════════
function renderCart(){
  const b=document.getElementById('cartBody');updateBadges();
  if(!cart.length){
    const s=pickSlogan(SLOGANS.emptyCart);
    b.innerHTML=`<div class="empty-state"><div class="empty-icon">🛒</div>
      <div class="empty-slogan">"${_e(s)}"</div>
      <p style="font-size:.84rem;">Your cart is empty. Shop some lenses!</p><br>
      <button onclick="openCollection('all')" style="margin-top:13px;padding:11px 26px;border-radius:10px;border:none;background:var(--primary);color:white;font-weight:700;font-size:.93rem;cursor:pointer;font-family:Manrope,sans-serif;">Shop Now</button></div>`;
    return;
  }
  const sub=cart.reduce((s,i)=>s+i.price*i.qty,0),del=sub>1500?0:60,tot=sub+del;
  b.innerHTML=cart.map((item,idx)=>`
    <div class="cart-item">
      <div class="cart-item-img"><img src="${IMAGES[item.img]}" alt="${_e(item.name)}"></div>
      <div style="flex:1;">
        <div class="cart-item-name">${_e(item.name)}</div>
        <div class="cart-item-meta">Power: ${_e(item.power)} • 6 lenses/box</div>
        <div class="cart-item-price">₹${item.price}</div>
        <div class="qty-control">
          <button class="qty-btn" onclick="changeQty(${idx},-1)">−</button>
          <span class="qty-val">${item.qty}</span>
          <button class="qty-btn" onclick="changeQty(${idx},1)">+</button>
          <button class="remove-btn" onclick="removeItem(${idx})">🗑 Remove</button>
        </div>
      </div>
    </div>`).join('')+`
    <div class="cart-summary">
      <div class="cart-row"><span>Subtotal</span><span>₹${sub}</span></div>
      <div class="cart-row"><span>Delivery</span><span>${del===0?'<span style="color:var(--success)">FREE</span>':'₹'+del}</span></div>
      ${del>0?'<div style="font-size:.74rem;color:var(--text-light);margin-bottom:8px;">Free delivery on orders above ₹1500</div>':''}
      <div class="cart-row total"><span>Total</span><span>₹${tot}</span></div>
      <button class="checkout-btn" onclick="goToCheckout()">Proceed to Checkout →</button>
    </div>`;
}

// ═══════════════════════════════════════
//  PRODUCT DETAIL
// ═══════════════════════════════════════
function openProduct(id){
  if(!isLoggedIn){showToast('Please login first');return;}
  currentProduct=PRODUCTS.find(p=>p.id===id);selectedPower=null;if(!currentProduct)return;
  closeProdOverlay();
  document.getElementById('detailImg').src=IMAGES[currentProduct.img];
  document.getElementById('detailBrand').textContent=currentProduct.brand;
  document.getElementById('detailName').textContent=currentProduct.name;
  document.getElementById('detailPrice').innerHTML=`₹${currentProduct.price} <span style="font-size:.86rem;color:var(--text-light);font-weight:400;text-decoration:line-through;">₹${currentProduct.oldPrice}</span> <span style="font-size:.76rem;background:#E8F5E9;color:#2E7D32;padding:3px 9px;border-radius:20px;">Save ₹${currentProduct.oldPrice-currentProduct.price}</span>`;
  document.getElementById('detailStars').innerHTML=stars(currentProduct.rating)+`<span style="font-size:.8rem;color:var(--text-light);">${currentProduct.rating} (${currentProduct.reviews} reviews)</span>`;
  document.getElementById('detailBadges').innerHTML=currentProduct.badges.map(b=>`<span class="detail-badge">${_e(b)}</span>`).join('');
  document.getElementById('detailDesc').textContent=currentProduct.desc;
  document.getElementById('powerGrid').innerHTML=currentProduct.powers.map(pw=>`<button class="power-chip" onclick="pickPower(this,'${_e(pw)}')">${_e(pw)}</button>`).join('');
  renderRec('detailRec',id);goTo('detailPage');
}
function pickPower(el,pw){document.querySelectorAll('.power-chip').forEach(c=>c.classList.remove('selected'));el.classList.add('selected');selectedPower=pw;}
function addFromDetail(){if(!selectedPower){showToast('⚠️ Please select a power first');return;}addToCart(currentProduct,selectedPower);}
function buyNowClick(){if(!selectedPower){showToast('⚠️ Please select a power first');return;}addToCart(currentProduct,selectedPower);goToCheckout();}
function quickAdd(id){if(!isLoggedIn){showToast('Please login first');return;}const p=PRODUCTS.find(x=>x.id===id);addToCart(p,'Ask seller');}

// ═══════════════════════════════════════
//  TRY-ON — MediaPipe Face Mesh powered (real eye tracking)
// ═══════════════════════════════════════
let tryStream=null;
let faceMesh=null;
let mpFrameLoop=false;
let fallbackAnimId=null;
let tryOnCtx=null;
let latestLandmarks=null;
let faceDetected=false;

// MediaPipe Face Mesh landmark indices (refineLandmarks:true gives 478 points,
// the last 10 are the iris rings — these give real, per-frame eye positions).
const RIGHT_IRIS_CENTER=468, RIGHT_IRIS_L=469, RIGHT_IRIS_R=471;
const LEFT_IRIS_CENTER=473,  LEFT_IRIS_L=474,  LEFT_IRIS_R=476;

const LENS_FX={
  soflens59:{ring:'rgba(200,230,255,0.55)',pupil:'rgba(30,100,200,0.20)'},
  soflens_astig:{ring:'rgba(180,200,240,0.55)',pupil:'rgba(60,80,180,0.20)'},
  purevision2:{ring:'rgba(160,210,255,0.6)',pupil:'rgba(20,90,220,0.24)'},
  purevision2_astig:{ring:'rgba(150,200,240,0.6)',pupil:'rgba(40,80,200,0.24)'},
  aspire_pro:{ring:'rgba(120,200,255,0.58)',pupil:'rgba(10,130,220,0.22)'},
  aspire_air:{ring:'rgba(130,225,210,0.58)',pupil:'rgba(10,160,150,0.22)'},
  biomedics_now:{ring:'rgba(170,210,170,0.58)',pupil:'rgba(40,140,60,0.22)'},
  proclear:{ring:'rgba(255,190,150,0.58)',pupil:'rgba(220,110,40,0.22)'}
};

function requestTryOn(){
  if(!currentProduct)return;
  pendingTryOnProduct=currentProduct;
  document.getElementById('camPermModal').classList.add('show');
}
function closeCamPermModal(){document.getElementById('camPermModal').classList.remove('show');}
function proceedToCamera(){
  closeCamPermModal();
  document.getElementById('tryOnModal').classList.add('show');
  document.getElementById('tryOnProductName').textContent=currentProduct.name;
  document.getElementById('tryOnStatus').textContent='';
  startTryOn();
}
function closeTryOn(){document.getElementById('tryOnModal').classList.remove('show');stopTryOn();}

function stopTryOn(){
  mpFrameLoop=false;
  if(fallbackAnimId){cancelAnimationFrame(fallbackAnimId);fallbackAnimId=null;}
  if(faceMesh){try{faceMesh.close();}catch(e){}faceMesh=null;}
  if(tryStream){tryStream.getTracks().forEach(t=>t.stop());tryStream=null;}
  const v=document.getElementById('tryOnVideo');if(v)v.srcObject=null;
  const c=document.getElementById('tryOnCanvas');
  if(c){const ctx=c.getContext('2d');ctx.clearRect(0,0,c.width,c.height);}
  document.getElementById('tryOnLoading').style.display='none';
  latestLandmarks=null;faceDetected=false;
}

function startTryOn(){
  const video=document.getElementById('tryOnVideo');
  const status=document.getElementById('tryOnStatus');
  const loading=document.getElementById('tryOnLoading');
  const loadingText=document.getElementById('tryOnLoadingText');
  status.textContent='';
  loading.style.display='flex';
  loadingText.textContent='Requesting camera access…';

  if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){
    loading.style.display='none';
    status.textContent='Camera is not supported in this browser. Please try Chrome or Safari.';
    return;
  }

  // Try ideal constraints first, fall back to basic if it fails
  const constraintsList=[
    {video:{facingMode:'user',width:{ideal:640},height:{ideal:480}}},
    {video:{facingMode:'user'}},
    {video:true}
  ];

  function tryNext(i){
    if(i>=constraintsList.length){
      loading.style.display='none';
      status.textContent='📷 Unable to start camera. Please check your device has a working camera.';
      return;
    }
    navigator.mediaDevices.getUserMedia(constraintsList[i])
      .then(stream=>{
        tryStream=stream;
        video.srcObject=stream;
        loadingText.textContent='Loading face tracking model…';
        video.onloadedmetadata=()=>{
          video.play().then(()=>{
            initFaceMesh(video);
          }).catch(err=>{
            loading.style.display='none';
            status.textContent='Could not start video preview: '+err.message;
          });
        };
      })
      .catch(err=>{
        if(i<constraintsList.length-1){tryNext(i+1);return;}
        loading.style.display='none';
        if(err.name==='NotAllowedError'||err.name==='PermissionDeniedError'){
          status.textContent='📷 Camera access was denied. Please allow camera permission in your browser settings and try again.';
        }else if(err.name==='NotFoundError'||err.name==='DevicesNotFoundError'){
          status.textContent='📷 No camera found on this device.';
        }else if(err.name==='NotReadableError'){
          status.textContent='📷 Camera is already in use by another app. Close it and try again.';
        }else{
          status.textContent='📷 Camera error: '+err.message;
        }
      });
  }
  tryNext(0);
}

// Sets up MediaPipe Face Mesh for real, per-frame eye landmark tracking.
// If the library failed to load (e.g. offline / CSP blocked), we degrade
// gracefully to a fixed-position overlay instead of breaking the feature.
function initFaceMesh(video){
  const canvas=document.getElementById('tryOnCanvas');
  tryOnCtx=canvas.getContext('2d');
  const loading=document.getElementById('tryOnLoading');
  const status=document.getElementById('tryOnStatus');

  const hasMediaPipe=(typeof FaceMesh!=='undefined');

  if(!hasMediaPipe){
    loading.style.display='none';
    status.textContent='⚠️ Live face tracking unavailable (offline?) — showing basic overlay.';
    drawLensOverlayFallback(canvas,video);
    return;
  }

  try{
    faceMesh=new FaceMesh({
      locateFile:(file)=>`https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh@0.4.1633559619/${file}`
    });
    faceMesh.setOptions({
      maxNumFaces:1,
      refineLandmarks:true,      // enables the iris landmarks (indices 468-477)
      minDetectionConfidence:0.6,
      minTrackingConfidence:0.6
    });
    faceMesh.onResults(onFaceMeshResults);
  }catch(e){
    faceMesh=null;
    loading.style.display='none';
    status.textContent='⚠️ Could not start face tracking — showing basic overlay.';
    drawLensOverlayFallback(canvas,video);
    return;
  }

  loading.style.display='none';
  mpFrameLoop=true;

  (async function pump(){
    if(!mpFrameLoop||!tryStream||!faceMesh)return;
    try{
      await faceMesh.send({image:video});
    }catch(e){
      // transient per-frame failure — keep the loop alive
    }
    if(mpFrameLoop)requestAnimationFrame(pump);
  })();
}

// Called by MediaPipe with the detected face landmarks for the current frame.
function onFaceMeshResults(results){
  const canvas=document.getElementById('tryOnCanvas');
  if(!canvas||!tryStream)return;
  const rect=canvas.getBoundingClientRect();
  if(canvas.width!==Math.round(rect.width))canvas.width=Math.round(rect.width)||320;
  if(canvas.height!==Math.round(rect.height))canvas.height=Math.round(rect.height)||240;
  const ctx=tryOnCtx||canvas.getContext('2d');
  ctx.clearRect(0,0,canvas.width,canvas.height);

  const status=document.getElementById('tryOnStatus');

  if(!results.multiFaceLandmarks||results.multiFaceLandmarks.length===0){
    faceDetected=false;
    latestLandmarks=null;
    if(status)status.textContent='🙂 No face detected — center your face in the frame.';
    return;
  }

  faceDetected=true;
  if(status)status.textContent='';
  latestLandmarks=results.multiFaceLandmarks[0];
  drawLensOverlay(ctx,canvas.width,canvas.height,latestLandmarks,false);
}

// Turns raw iris landmarks into on-canvas eye position + radius.
// mirror=true flips X (used only for the saved/downloaded photo, since that
// canvas isn't CSS-mirrored the way the live preview canvas is).
function eyeGeometry(landmarks,w,h,mirror){
  const pt=(idx)=>{
    const lm=landmarks[idx];
    const nx=mirror?(1-lm.x):lm.x;
    return{x:nx*w,y:lm.y*h};
  };
  const leftC=pt(LEFT_IRIS_CENTER), leftA=pt(LEFT_IRIS_L), leftB=pt(LEFT_IRIS_R);
  const rightC=pt(RIGHT_IRIS_CENTER), rightA=pt(RIGHT_IRIS_L), rightB=pt(RIGHT_IRIS_R);
  const leftR=Math.hypot(leftA.x-leftB.x,leftA.y-leftB.y)/2*1.35;
  const rightR=Math.hypot(rightA.x-rightB.x,rightA.y-rightB.y)/2*1.35;
  return[{x:leftC.x,y:leftC.y,r:leftR},{x:rightC.x,y:rightC.y,r:rightR}];
}

function drawLensOverlay(ctx,w,h,landmarks,mirror){
  const style=LENS_FX[currentProduct.img]||LENS_FX.soflens59;
  const eyes=eyeGeometry(landmarks,w,h,!!mirror);
  eyes.forEach(eye=>{
    const grad=ctx.createRadialGradient(eye.x,eye.y,eye.r*0.28,eye.x,eye.y,eye.r);
    grad.addColorStop(0,style.pupil);grad.addColorStop(0.65,style.ring);grad.addColorStop(1,'rgba(255,255,255,0)');
    ctx.beginPath();ctx.arc(eye.x,eye.y,eye.r,0,Math.PI*2);ctx.fillStyle=grad;ctx.fill();
    ctx.beginPath();ctx.arc(eye.x,eye.y,eye.r,0,Math.PI*2);ctx.strokeStyle=style.ring;ctx.lineWidth=2;ctx.stroke();
    ctx.beginPath();ctx.arc(eye.x-eye.r*0.25,eye.y-eye.r*0.25,eye.r*0.18,0,Math.PI*2);ctx.fillStyle='rgba(255,255,255,0.5)';ctx.fill();
  });
}

// Fallback overlay (fixed proportional eye positions) — only used if the
// MediaPipe Face Mesh library couldn't be loaded, so try-on still works.
function drawLensOverlayFallback(canvas,video){
  const style=LENS_FX[currentProduct.img]||LENS_FX.soflens59;
  let frame=0;
  function animate(){
    if(!tryStream)return;
    const rect=canvas.getBoundingClientRect();
    if(canvas.width!==Math.round(rect.width))canvas.width=Math.round(rect.width)||320;
    if(canvas.height!==Math.round(rect.height))canvas.height=Math.round(rect.height)||240;
    const ctx=canvas.getContext('2d');
    ctx.clearRect(0,0,canvas.width,canvas.height);
    const cx=canvas.width,cy=canvas.height;
    const eyes=[{x:cx*0.37,y:cy*0.40},{x:cx*0.63,y:cy*0.40}];
    const r=Math.min(cx,cy)*0.088;
    const pulse=1+0.025*Math.sin(frame*0.05);
    eyes.forEach(eye=>{
      const grad=ctx.createRadialGradient(eye.x,eye.y,r*0.3,eye.x,eye.y,r*pulse);
      grad.addColorStop(0,style.pupil);grad.addColorStop(0.6,style.ring);grad.addColorStop(1,'rgba(255,255,255,0)');
      ctx.beginPath();ctx.arc(eye.x,eye.y,r*pulse,0,Math.PI*2);ctx.fillStyle=grad;ctx.fill();
      ctx.beginPath();ctx.arc(eye.x,eye.y,r*pulse,0,Math.PI*2);ctx.strokeStyle=style.ring;ctx.lineWidth=2.5;ctx.stroke();
      ctx.beginPath();ctx.arc(eye.x-r*0.25,eye.y-r*0.25,r*0.18,0,Math.PI*2);ctx.fillStyle='rgba(255,255,255,0.5)';ctx.fill();
    });
    frame++;
    if(tryStream)fallbackAnimId=requestAnimationFrame(animate);
  }
  animate();
}

function captureTryOn(){
  const video=document.getElementById('tryOnVideo');
  if(!video||!video.videoWidth){showToast('Camera not ready yet — please wait a moment');return;}
  const canvas=document.createElement('canvas');
  canvas.width=video.videoWidth;canvas.height=video.videoHeight;
  const ctx=canvas.getContext('2d');
  ctx.save();ctx.scale(-1,1);ctx.drawImage(video,-canvas.width,0);ctx.restore();

  if(faceDetected&&latestLandmarks){
    drawLensOverlay(ctx,canvas.width,canvas.height,latestLandmarks,true);
  }else{
    // No live landmarks (fallback mode, or face briefly lost) — approximate.
    const style=LENS_FX[currentProduct.img]||LENS_FX.soflens59;
    const cx=canvas.width,cy=canvas.height;
    const eyes=[{x:cx*0.37,y:cy*0.40},{x:cx*0.63,y:cy*0.40}];
    const r=Math.min(cx,cy)*0.088;
    eyes.forEach(eye=>{
      const grad=ctx.createRadialGradient(eye.x,eye.y,r*0.3,eye.x,eye.y,r);
      grad.addColorStop(0,style.pupil);grad.addColorStop(0.6,style.ring);grad.addColorStop(1,'rgba(255,255,255,0)');
      ctx.beginPath();ctx.arc(eye.x,eye.y,r,0,Math.PI*2);ctx.fillStyle=grad;ctx.fill();
      ctx.beginPath();ctx.arc(eye.x,eye.y,r,0,Math.PI*2);ctx.strokeStyle=style.ring;ctx.lineWidth=3;ctx.stroke();
    });
  }

  canvas.toBlob(blob=>{
    const url=URL.createObjectURL(blob);
    const link=document.createElement('a');link.download='lensly-tryon.png';link.href=url;link.click();
    setTimeout(()=>URL.revokeObjectURL(url),5000);
    showToast('📸 Photo saved!');
  },'image/png');
}


// ═══════════════════════════════════════
//  CART LOGIC
// ═══════════════════════════════════════
function addToCart(product,power){
  const ex=cart.find(i=>i.id===product.id&&i.power===power);
  if(ex){ex.qty++;}else{cart.push({id:product.id,img:product.img,name:product.name,price:product.price,power,qty:1});}
  saveCart();updateBadges();showToast('✅ Added to cart!');
}
function changeQty(idx,d){cart[idx].qty+=d;if(cart[idx].qty<=0)cart.splice(idx,1);saveCart();renderCart();}
function removeItem(idx){cart.splice(idx,1);saveCart();renderCart();showToast('Removed from cart');}
function saveCart(){safeStore('cart',cart);}
function resetCart(){cart=[];saveCart();updateBadges();}
function updateBadges(){const n=cart.reduce((s,i)=>s+i.qty,0);document.querySelectorAll('#cartBadge,#cartBadge2').forEach(b=>b.textContent=n);}

// ═══════════════════════════════════════
//  CHECKOUT
// ═══════════════════════════════════════
function goToCheckout(){
  const sub=cart.reduce((s,i)=>s+i.price*i.qty,0),del=sub>1500?0:60;
  document.getElementById('coSummary').innerHTML=cart.map(i=>`<div class="cart-row"><span>${_e(i.name)} (${_e(i.power)}) ×${i.qty}</span><span>₹${i.price*i.qty}</span></div>`).join('')+`<div class="cart-row total"><span>Total</span><span>₹${sub+del}</span></div>`;
  goTo('checkoutPage');renderCheckoutSlogan();
  // pre-fill from profile
  if(userProfile.name)document.getElementById('coName').value=userProfile.name;
  if(userProfile.phone)document.getElementById('coPhone').value=userProfile.phone;
  if(userProfile.email)document.getElementById('coEmail').value=userProfile.email;
}
function renderCheckoutSlogan(){const e=document.getElementById('checkoutSlogan');if(e)e.textContent=pickSlogan(SLOGANS.checkout);}

function goToPayment(){
  const name=document.getElementById('coName').value.trim();
  const phone=document.getElementById('coPhone').value.trim();
  const addr1=document.getElementById('coAddr1').value.trim();
  const city=document.getElementById('coCity').value.trim();
  const pin=document.getElementById('coPin').value.trim();
  if(!name){showToast('⚠️ Please enter your name');return;}
  if(!phone||phone.replace(/\D/g,'').length<10){showToast('⚠️ Enter a valid phone number');return;}
  if(!addr1){showToast('⚠️ Enter house / flat details');return;}
  if(!city){showToast('⚠️ Enter your city');return;}
  if(!pin||pin.length<6){showToast('⚠️ Enter a valid PIN code');return;}
  const sub=cart.reduce((s,i)=>s+i.price*i.qty,0),del=sub>1500?0:60;
  document.getElementById('payAmount').textContent='₹'+(sub+del);
  selPayment=null;
  document.querySelectorAll('.payment-option').forEach(o=>o.classList.remove('selected'));
  document.getElementById('upiSec').style.display='none';
  document.getElementById('cardSec').style.display='none';
  goTo('paymentPage');
}

// ═══════════════════════════════════════
//  PAYMENT
// ═══════════════════════════════════════
function selPay(el,type){
  document.querySelectorAll('.payment-option').forEach(o=>o.classList.remove('selected'));
  el.classList.add('selected');selPayment=type;
  document.getElementById('upiSec').style.display=type==='upi'?'block':'none';
  document.getElementById('cardSec').style.display=type==='card'?'block':'none';
}
function confirmPayment(){
  if(!selPayment){showToast('⚠️ Please select a payment method');return;}
  orderNum++;
  const orderId='#LNS'+String(orderNum).padStart(6,'0');
  document.getElementById('trackingId').textContent='Order ID: '+orderId;
  const orders=safeRead('orders',[]);
  cart.forEach(item=>{
    const prod=PRODUCTS.find(p=>p.id===item.id);
    orders.push({orderId,productName:item.name,productId:item.id,wearDays:prod?prod.wearDays:30,placedAt:Date.now(),reminded:false,
      qty:item.qty,price:item.price,power:item.power,status:'Confirmed'});
  });
  safeStore('orders',orders);
  document.getElementById('confirmSlogan').textContent=pickSlogan(SLOGANS.orderConfirm);
  pageHistory=[];goTo('trackingPage');
  showToast('🎉 Order placed successfully!');
  resetCart();
}

// ═══════════════════════════════════════
//  REORDER NOTIFICATIONS
// ═══════════════════════════════════════
function checkReorderNotifications(){
  const orders=safeRead('orders',[]);if(!orders.length)return;
  const now=Date.now();let changed=false;
  orders.forEach(order=>{
    if(order.reminded)return;
    const expiresAt=order.placedAt+(order.wearDays*86400000);
    if(now>=expiresAt-(2*86400000)){setTimeout(()=>showReorderBanner(order),1500);order.reminded=true;changed=true;}
  });
  if(changed)safeStore('orders',orders);
}
function showReorderBanner(order){
  const msg=pickSlogan(SLOGANS.reorder);
  document.getElementById('reorderMsg').textContent=msg;
  document.getElementById('reorderProduct').textContent='🔔 Reminder: '+order.productName+' is about to run out!';
  const b=document.getElementById('reorderBanner');
  b.style.display='flex';setTimeout(()=>b.style.opacity=1,50);
}
function dismissReorder(){const b=document.getElementById('reorderBanner');b.style.opacity=0;setTimeout(()=>b.style.display='none',400);}

// ═══════════════════════════════════════
//  PROFILE
// ═══════════════════════════════════════
function renderProfile(){
  const orders=safeRead('orders',[]);
  document.getElementById('statOrders').textContent=new Set(orders.map(o=>o.orderId)).size;
  document.getElementById('statCart').textContent=cart.reduce((s,i)=>s+i.qty,0);
  const saved=PRODUCTS.reduce((s,p)=>s+(p.oldPrice-p.price),0);
  document.getElementById('statSaved').textContent='₹'+orders.reduce((s,o)=>s+((o.price||0)*(o.qty||1)*0.2),0).toFixed(0);

  const name=userProfile.name||'Guest User';
  document.getElementById('profileAvatarLg').textContent=name.charAt(0).toUpperCase();
  document.getElementById('profileNameLg').textContent=name;
  document.getElementById('profileMetaLg').textContent=userProfile.email||userProfile.phone||'Member since today';
  document.getElementById('profName').value=userProfile.name||'';
  document.getElementById('profEmail').value=userProfile.email||'';
  document.getElementById('profPhone').value=userProfile.phone||'';

  const list=document.getElementById('profileOrdersList');
  if(!orders.length){
    list.innerHTML='<p style="font-size:.82rem;color:var(--text-light);">No orders yet.</p>';
  }else{
    const grouped={};
    orders.forEach(o=>{if(!grouped[o.orderId])grouped[o.orderId]=[];grouped[o.orderId].push(o);});
    list.innerHTML=Object.entries(grouped).reverse().slice(0,5).map(([oid,items])=>{
      const total=items.reduce((s,i)=>s+(i.price*i.qty),0);
      return `<div class="profile-list-item">
        <div class="profile-list-icon">📦</div>
        <div class="profile-list-text">
          <div class="profile-list-title">${_e(oid)}</div>
          <div class="profile-list-sub">${items.length} item${items.length>1?'s':''} • ₹${total}</div>
        </div>
      </div>`;
    }).join('');
  }
}
function saveProfile(){
  const name=document.getElementById('profName').value.trim();
  const email=document.getElementById('profEmail').value.trim();
  const phone=document.getElementById('profPhone').value.trim();
  if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){showToast('⚠️ Enter a valid email address');return;}
  userProfile={name,email,phone};
  safeStore('profile',userProfile);
  renderProfile();
  showToast('✅ Profile updated!');
}

// ═══════════════════════════════════════
//  TOAST
// ═══════════════════════════════════════
function showToast(msg){
  const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');
  clearTimeout(window._tt);window._tt=setTimeout(()=>t.classList.remove('show'),2800);
}

// ═══════════════════════════════════════
//  INIT
// ═══════════════════════════════════════
selectChannel('whatsapp');
updateBadges();
runSplash();



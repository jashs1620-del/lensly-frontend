// Lensly backend — placeholder server.
//
// Your uploaded file only contained the frontend (index.html). Your VS Code
// screenshot shows a "lensly-backend" folder already exists in your project —
// paste its real contents into this folder and this stub will get out of the way.
//
// This stub just serves the frontend as static files so you have something
// runnable immediately, and shows the shape of a simple Express server ready
// for you to add real routes (products, cart, auth, orders) later.

const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve the frontend build
app.use(express.static(path.join(__dirname, '..')));

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'lensly-backend' });
});

app.listen(PORT, () => {
  console.log(`Lensly backend running at http://localhost:${PORT}`);
});
